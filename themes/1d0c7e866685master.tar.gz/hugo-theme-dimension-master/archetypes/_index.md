---
title: "{{ replace .Name "-" " " | title }}"
date: {{ .Date }}
background: "/images/bg.jpg"
logo: "gem"
---