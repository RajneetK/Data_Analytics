---
title: '{{ replace .TranslationBaseName "-" " " | title }}'
date: {{ .Date }}
draft: true
meta_img: "images/image.png"
tags:
  - "one tag"
  - "another tag"
description: "Description for the page"
---
